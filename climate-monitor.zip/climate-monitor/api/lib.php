<?php
// =====================================================
// SHARED HELPERS (database + JSON responses)
// =====================================================

function config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require __DIR__ . '/config.php';
    }
    return $cfg;
}

function send_headers(string $methods = 'GET, POST, OPTIONS'): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Methods: $methods");
    header('Access-Control-Allow-Headers: Content-Type, X-API-Key');
    header('Cache-Control: no-store');

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function json_out(array $payload, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION);
    exit;
}

function fail(string $message, int $code = 400): void
{
    json_out(['status' => 'error', 'message' => $message], $code);
}

function db(): mysqli
{
    static $conn = null;
    if ($conn !== null) {
        return $conn;
    }

    mysqli_report(MYSQLI_REPORT_OFF);
    $c = config()['db'];
    $conn = @new mysqli($c['host'], $c['user'], $c['pass'], $c['name']);

    if ($conn->connect_error) {
        // Do not leak connection details to the client
        error_log('IoT API DB connect failed: ' . $conn->connect_error);
        fail('Database connection failed', 500);
    }

    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+00:00'");   // store & read everything in UTC
    return $conn;
}

/** Convert a "Y-m-d H:i:s" UTC string to ISO-8601 with Z suffix. */
function iso_utc(?string $ts): ?string
{
    if ($ts === null) {
        return null;
    }
    return str_replace(' ', 'T', $ts) . 'Z';
}

/** Read a bounded numeric query parameter. */
function param_float(string $name, float $default, float $min, float $max): float
{
    if (!isset($_GET[$name]) || !is_numeric($_GET[$name])) {
        return $default;
    }
    return max($min, min($max, (float) $_GET[$name]));
}

/** Read and validate the optional device filter ('' = all devices). */
function param_device(): string
{
    $d = $_GET['device'] ?? '';
    if ($d === '') {
        return '';
    }
    if (!preg_match('/^[A-Za-z0-9_-]{1,32}$/', $d)) {
        fail('Invalid device id');
    }
    return $d;
}
