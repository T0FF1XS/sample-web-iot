<?php
// =====================================================
// CONFIGURATION
// Values can be overridden with environment variables
// so secrets never have to be committed to git.
// =====================================================

return [

    'db' => [
        'host' => getenv('IOT_DB_HOST') ?: 'localhost',
        'name' => getenv('IOT_DB_NAME') ?: 'iot_db',
        'user' => getenv('IOT_DB_USER') ?: 'root',
        'pass' => getenv('IOT_DB_PASS') !== false ? getenv('IOT_DB_PASS') : '',
    ],

    // Shared secret the ESP32 sends in the X-API-Key header.
    // CHANGE THIS and keep it identical in esp32/esp32.ino
    'api_key' => getenv('IOT_API_KEY') ?: 'change-me-secret-key',

    // Seconds between readings from the ESP32 (SEND_INTERVAL / 1000)
    'expected_interval' => 5,

    // Sensor considered OFFLINE if nothing received for this long (seconds)
    'offline_after' => 60,

    // Thresholds used by the insights engine
    'thresholds' => [
        'temp_warn_high' => 27.0,   // deg C
        'temp_crit_high' => 30.0,
        'temp_warn_low'  => 18.0,
        'temp_crit_low'  => 15.0,
        'hum_warn_high'  => 65.0,   // % RH
        'hum_crit_high'  => 75.0,
        'hum_warn_low'   => 30.0,
        'rise_rate'      => 2.0,    // deg C per hour counted as "fast rise"
    ],
];
