<?php
// =====================================================
// SENSOR API
//
//   POST api.php              ESP32 uploads a reading   (needs X-API-Key)
//   GET  api.php?hours=1      reading history for charts
//   GET  api.php?devices=1    list of known devices
//
// GET parameters: device, hours (0.1 - 720, default 1)
// =====================================================

require_once __DIR__ . '/lib.php';

send_headers();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// -----------------------------------------------------
// POST - store a reading
// -----------------------------------------------------
if ($method === 'POST') {

    $key = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if (!hash_equals(config()['api_key'], $key)) {
        fail('Unauthorized', 401);
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        fail('Invalid JSON');
    }

    if (!isset($data['temperature'], $data['humidity'])
        || !is_numeric($data['temperature'])
        || !is_numeric($data['humidity'])) {
        fail('temperature and humidity are required numbers');
    }

    $device = $data['device_id'] ?? 'esp32-01';
    if (!is_string($device) || !preg_match('/^[A-Za-z0-9_-]{1,32}$/', $device)) {
        fail('device_id must be 1-32 chars: letters, digits, - or _');
    }

    $temperature = (float) $data['temperature'];
    $humidity    = (float) $data['humidity'];

    if ($temperature < -50 || $temperature > 100) {
        fail('Invalid temperature');
    }
    if ($humidity < 0 || $humidity > 100) {
        fail('Invalid humidity');
    }

    $rssi = null;
    if (isset($data['rssi']) && is_numeric($data['rssi'])) {
        $rssi = (int) $data['rssi'];
        if ($rssi < -120 || $rssi > 0) {
            $rssi = null;
        }
    }

    $conn = db();

    $stmt = $conn->prepare(
        'INSERT INTO sensor_data (device_id, temperature, humidity, rssi) VALUES (?, ?, ?, ?)'
    );
    $stmt->bind_param('sddi', $device, $temperature, $humidity, $rssi);

    if (!$stmt->execute()) {
        error_log('IoT API insert failed: ' . $stmt->error);
        fail('Database insert failed', 500);
    }
    $id = $stmt->insert_id;
    $stmt->close();

    // Register device / update heartbeat
    $up = $conn->prepare(
        'INSERT INTO devices (device_id, last_seen) VALUES (?, UTC_TIMESTAMP())
         ON DUPLICATE KEY UPDATE last_seen = UTC_TIMESTAMP()'
    );
    $up->bind_param('s', $device);
    $up->execute();
    $up->close();

    json_out([
        'status'      => 'success',
        'message'     => 'Sensor data saved',
        'id'          => $id,
        'device_id'   => $device,
        'temperature' => $temperature,
        'humidity'    => $humidity,
    ], 201);
}

// -----------------------------------------------------
// GET
// -----------------------------------------------------
if ($method === 'GET') {

    $conn = db();

    // ---- device list --------------------------------
    if (isset($_GET['devices'])) {
        $res = $conn->query(
            'SELECT device_id, name, location, last_seen FROM devices ORDER BY device_id'
        );
        $devices = [];
        while ($r = $res->fetch_assoc()) {
            $r['last_seen'] = iso_utc($r['last_seen']);
            $devices[] = $r;
        }
        json_out(['status' => 'success', 'count' => count($devices), 'data' => $devices]);
    }

    // ---- history ------------------------------------
    $device  = param_device();
    $hours   = param_float('hours', 1, 0.1, 720);
    $seconds = (int) round($hours * 3600);

    // Windows over 1 hour are averaged into ~360 buckets so the browser stays fast.
    $bucket = $hours <= 1 ? 0 : (int) ceil($seconds / 360);

    if ($bucket === 0) {
        $sql = "SELECT created_at,
                       temperature, humidity,
                       temperature AS t_min, temperature AS t_max,
                       humidity AS h_min, humidity AS h_max,
                       1 AS samples
                FROM sensor_data
                WHERE created_at >= UTC_TIMESTAMP() - INTERVAL ? SECOND
                  AND (? = '' OR device_id = ?)
                ORDER BY created_at DESC
                LIMIT 1000";
    } else {
        // $bucket is an integer computed above, safe to inline
        $sql = "SELECT FROM_UNIXTIME(FLOOR(UNIX_TIMESTAMP(created_at) / $bucket) * $bucket) AS created_at,
                       AVG(temperature) AS temperature, AVG(humidity) AS humidity,
                       MIN(temperature) AS t_min, MAX(temperature) AS t_max,
                       MIN(humidity)    AS h_min, MAX(humidity)    AS h_max,
                       COUNT(*) AS samples
                FROM sensor_data
                WHERE created_at >= UTC_TIMESTAMP() - INTERVAL ? SECOND
                  AND (? = '' OR device_id = ?)
                GROUP BY FLOOR(UNIX_TIMESTAMP(created_at) / $bucket)
                ORDER BY created_at DESC
                LIMIT 1000";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('iss', $seconds, $device, $device);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = [];
    while ($r = $res->fetch_assoc()) {
        $rows[] = [
            'created_at'  => iso_utc($r['created_at']),
            'temperature' => round((float) $r['temperature'], 2),
            'humidity'    => round((float) $r['humidity'], 2),
            'temp_min'    => round((float) $r['t_min'], 2),
            'temp_max'    => round((float) $r['t_max'], 2),
            'hum_min'     => round((float) $r['h_min'], 2),
            'hum_max'     => round((float) $r['h_max'], 2),
            'samples'     => (int) $r['samples'],
        ];
    }
    $stmt->close();

    json_out([
        'status'         => 'success',
        'device'         => $device ?: null,
        'hours'          => $hours,
        'bucket_seconds' => $bucket,
        'count'          => count($rows),
        'data'           => array_reverse($rows),   // oldest first
    ]);
}

fail('Method not allowed', 405);
