<?php
// =====================================================
// INSIGHTS ENGINE
//
//   GET insights.php?hours=24&device=esp32-01
//
// Turns raw readings into derived metrics (dew point,
// heat index, comfort score, trend) and plain-language,
// actionable recommendations.
// =====================================================

require_once __DIR__ . '/lib.php';

send_headers('GET, OPTIONS');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    fail('Method not allowed', 405);
}

$cfg    = config();
$th     = $cfg['thresholds'];
$conn   = db();
$device = param_device();
$hours  = param_float('hours', 24, 0.1, 720);
$secs   = (int) round($hours * 3600);

// ---------- pure helper functions ----------------------

/** Dew point in deg C (Magnus formula). */
function dew_point(float $t, float $rh): float
{
    $a = 17.62; $b = 243.12;
    $g = log(max($rh, 0.1) / 100) + ($a * $t) / ($b + $t);
    return ($b * $g) / ($a - $g);
}

/** "Feels like" temperature in deg C (NOAA Rothfusz regression, hot weather only). */
function heat_index(float $tc, float $rh): float
{
    $t = $tc * 9 / 5 + 32;
    if ($t < 80) {
        return $tc;
    }
    $hi = -42.379 + 2.04901523 * $t + 10.14333127 * $rh - 0.22475541 * $t * $rh
        - 0.00683783 * $t * $t - 0.05481717 * $rh * $rh + 0.00122874 * $t * $t * $rh
        + 0.00085282 * $t * $rh * $rh - 0.00000199 * $t * $t * $rh * $rh;
    return ($hi - 32) * 5 / 9;
}

/** 0-100 comfort score: ideal is 20.5-24.5 C and 40-60 %RH. */
function comfort_score(float $t, float $rh): int
{
    $tPen = max(0, abs($t - 22.5) - 2.0) * 6.0;
    $hPen = max(0, abs($rh - 50.0) - 10.0) * 1.2;
    return (int) max(0, round(100 - $tPen - $hPen));
}

function comfort_label(int $score): string
{
    if ($score >= 80) return 'Comfortable';
    if ($score >= 60) return 'Acceptable';
    if ($score >= 40) return 'Uncomfortable';
    return 'Poor';
}

/** Least-squares slope. $xs in hours, returns units per hour. */
function slope(array $xs, array $ys): ?float
{
    $n = count($xs);
    if ($n < 5) {
        return null;
    }
    $mx = array_sum($xs) / $n;
    $my = array_sum($ys) / $n;
    $num = 0.0; $den = 0.0;
    for ($i = 0; $i < $n; $i++) {
        $num += ($xs[$i] - $mx) * ($ys[$i] - $my);
        $den += ($xs[$i] - $mx) ** 2;
    }
    return $den > 0 ? $num / $den : null;
}

function direction(?float $perHour, float $flat): string
{
    if ($perHour === null || abs($perHour) < $flat) return 'stable';
    return $perHour > 0 ? 'rising' : 'falling';
}

function add(array &$list, string $sev, string $title, string $detail, string $action): void
{
    $list[] = ['severity' => $sev, 'title' => $title, 'detail' => $detail, 'action' => $action];
}

// ---------- 1. latest reading --------------------------

$stmt = $conn->prepare(
    "SELECT device_id, temperature, humidity, rssi, created_at,
            TIMESTAMPDIFF(SECOND, created_at, UTC_TIMESTAMP()) AS age
     FROM sensor_data
     WHERE (? = '' OR device_id = ?)
     ORDER BY created_at DESC, id DESC LIMIT 1"
);
$stmt->bind_param('ss', $device, $device);
$stmt->execute();
$latest = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$latest) {
    json_out([
        'status'    => 'success',
        'online'    => false,
        'latest'    => null,
        'insights'  => [[
            'severity' => 'info',
            'title'    => 'No data yet',
            'detail'   => 'The database has no readings for this selection.',
            'action'   => 'Power on the ESP32 or run simulator/simulate.py, then refresh.',
        ]],
    ]);
}

// "All devices" would mix different rooms, so analyse the most recently active node
if ($device === '') {
    $device = $latest['device_id'];
}

$t   = (float) $latest['temperature'];
$rh  = (float) $latest['humidity'];
$age = (int) $latest['age'];
$online = $age <= $cfg['offline_after'];

// ---------- 2. window statistics -----------------------

$stmt = $conn->prepare(
    "SELECT COUNT(*) n,
            AVG(temperature) t_avg, MIN(temperature) t_min, MAX(temperature) t_max, STDDEV_SAMP(temperature) t_sd,
            AVG(humidity)    h_avg, MIN(humidity)    h_min, MAX(humidity)    h_max, STDDEV_SAMP(humidity)    h_sd,
            SUM(temperature > ?) t_hot_n, SUM(humidity > ?) h_high_n,
            MIN(created_at) first_ts
     FROM sensor_data
     WHERE created_at >= UTC_TIMESTAMP() - INTERVAL ? SECOND
       AND (? = '' OR device_id = ?)"
);
$stmt->bind_param('ddiss', $th['temp_warn_high'], $th['hum_warn_high'], $secs, $device, $device);
$stmt->execute();
$w = $stmt->get_result()->fetch_assoc();
$stmt->close();

$n = (int) $w['n'];

// ---------- 3. short-term trend (last 30 minutes) ------

$stmt = $conn->prepare(
    "SELECT temperature, humidity,
            TIMESTAMPDIFF(SECOND, created_at, UTC_TIMESTAMP()) / 3600 AS hours_ago
     FROM sensor_data
     WHERE created_at >= UTC_TIMESTAMP() - INTERVAL 30 MINUTE
       AND (? = '' OR device_id = ?)
     ORDER BY created_at DESC LIMIT 600"
);
$stmt->bind_param('ss', $device, $device);
$stmt->execute();
$res = $stmt->get_result();
$xs = []; $ts = []; $hs = [];
while ($r = $res->fetch_assoc()) {
    $xs[] = -1 * (float) $r['hours_ago'];
    $ts[] = (float) $r['temperature'];
    $hs[] = (float) $r['humidity'];
}
$stmt->close();

$tSlope = slope($xs, $ts);
$hSlope = slope($xs, $hs);

// ---------- 4. derived metrics -------------------------

$dew     = dew_point($t, $rh);
$feels   = heat_index($t, $rh);
$score   = comfort_score($t, $rh);

// Data completeness: received vs expected samples since the first reading in the window
$completeness = null;
if ($n > 1) {
    $spanSecs = max(1, strtotime($latest['created_at'] . ' UTC') - strtotime($w['first_ts'] . ' UTC'));
    $expected = $spanSecs / max(1, $cfg['expected_interval']) + 1;
    $completeness = (int) min(100, round($n / $expected * 100));
}

// ---------- 5. recommendations -------------------------

$ins = [];

if (!$online) {
    add($ins, 'critical', 'Sensor offline',
        sprintf('No data received for %s.', $age >= 3600 ? round($age / 3600, 1) . ' h' : max(1, round($age / 60)) . ' min'),
        'Check ESP32 power, WiFi, and that the server URL / API key in the firmware are correct.');
}

if ($t >= $th['temp_crit_high']) {
    add($ins, 'critical', 'Temperature too high',
        sprintf('%.1f °C is above the %.0f °C critical limit.', $t, $th['temp_crit_high']),
        'Turn on cooling or open windows; move heat-sensitive items and drink water.');
} elseif ($t >= $th['temp_warn_high']) {
    add($ins, 'warning', 'Room is getting warm',
        sprintf('%.1f °C is above the %.0f °C comfort limit.', $t, $th['temp_warn_high']),
        'Ventilate, close blinds on sunny sides, or switch on a fan / AC.');
} elseif ($t <= $th['temp_crit_low']) {
    add($ins, 'critical', 'Temperature too low',
        sprintf('%.1f °C is below the %.0f °C critical limit.', $t, $th['temp_crit_low']),
        'Heat the space and check for open windows or doors.');
} elseif ($t <= $th['temp_warn_low']) {
    add($ins, 'warning', 'Room is cool',
        sprintf('%.1f °C is below the %.0f °C comfort limit.', $t, $th['temp_warn_low']),
        'Raise the heating a little or close windows.');
}

if ($rh >= $th['hum_crit_high']) {
    add($ins, 'critical', 'Mold and condensation risk',
        sprintf('Humidity is %.0f %% (limit %.0f %%). Mold grows quickly above 70 %% RH.', $rh, $th['hum_crit_high']),
        'Run a dehumidifier or AC, ventilate, and avoid drying laundry indoors.');
} elseif ($rh >= $th['hum_warn_high']) {
    add($ins, 'warning', 'Humidity is high',
        sprintf('Humidity is %.0f %% (comfort limit %.0f %%).', $rh, $th['hum_warn_high']),
        'Ventilate or use a dehumidifier before it reaches the mold-risk zone.');
} elseif ($rh <= $th['hum_warn_low']) {
    add($ins, 'warning', 'Air is dry',
        sprintf('Humidity is %.0f %% (below %.0f %%).', $rh, $th['hum_warn_low']),
        'Use a humidifier or place water containers near heat sources to reduce dry skin and static.');
}

if ($t - $dew < 2.5 && $rh >= 60) {
    add($ins, 'warning', 'Condensation likely',
        sprintf('Dew point (%.1f °C) is within %.1f °C of the air temperature.', $dew, $t - $dew),
        'Cold surfaces such as windows and walls may start to sweat; improve ventilation.');
}

if ($feels - $t >= 3) {
    add($ins, 'warning', 'Feels hotter than it reads',
        sprintf('Heat index is %.1f °C (%.1f °C above the actual reading).', $feels, $feels - $t),
        'High humidity is amplifying the heat; prioritise dehumidifying and airflow.');
}

if ($tSlope !== null && $tSlope >= $th['rise_rate']) {
    add($ins, 'warning', 'Temperature rising fast',
        sprintf('+%.1f °C per hour over the last 30 minutes.', $tSlope),
        'Look for a new heat source (sun, equipment) and ventilate early.');
} elseif ($tSlope !== null && $tSlope <= -$th['rise_rate']) {
    add($ins, 'info', 'Temperature dropping fast',
        sprintf('%.1f °C per hour over the last 30 minutes.', $tSlope),
        'Check whether a window or door was opened or the AC is overcooling.');
}

// Share of the window spent outside comfort limits
if ($n >= 30) {
    $hotPct  = round((int) $w['t_hot_n'] / $n * 100);
    $humPct  = round((int) $w['h_high_n'] / $n * 100);
    if ($hotPct >= 25) {
        add($ins, 'warning', 'Frequently too warm',
            sprintf('Above %.0f °C for %d %% of the last %s.', $th['temp_warn_high'], $hotPct, $hours >= 24 ? round($hours / 24, 1) . ' day(s)' : round($hours, 1) . ' h'),
            'Consider shading, a schedule for cooling, or relocating the workload.');
    }
    if ($humPct >= 25) {
        add($ins, 'warning', 'Humidity often high',
            sprintf('Above %.0f %% RH for %d %% of the selected period.', $th['hum_warn_high'], $humPct),
            'A permanent fix (dehumidifier, exhaust fan, sealing leaks) is worthwhile.');
    }
}

// Unusual spike versus the window baseline (z-score)
if ($n >= 30 && (float) $w['t_sd'] > 0.1) {
    $z = ($t - (float) $w['t_avg']) / (float) $w['t_sd'];
    if (abs($z) >= 3) {
        add($ins, 'info', 'Unusual temperature reading',
            sprintf('Latest value is %.1f standard deviations from the average (%.1f °C).', abs($z), (float) $w['t_avg']),
            'Confirm it is real; otherwise check sensor placement away from heat sources and drafts.');
    }
}

if ($completeness !== null && $completeness < 80 && $n >= 30) {
    add($ins, 'info', 'Gaps in data',
        sprintf('Only %d %% of expected readings arrived in this period.', $completeness),
        'Check WiFi signal and power stability. Move the ESP32 closer to the router if RSSI is weak.');
}

if ($latest['rssi'] !== null && (int) $latest['rssi'] <= -80) {
    add($ins, 'info', 'Weak WiFi signal',
        sprintf('RSSI is %d dBm.', (int) $latest['rssi']),
        'Move the ESP32 closer to the router or add an access point to avoid dropped readings.');
}

if (!$ins) {
    add($ins, 'ok', 'Conditions are comfortable',
        sprintf('%.1f °C and %.0f %% RH are within the recommended range.', $t, $rh),
        'No action needed.');
}

$order = ['critical' => 0, 'warning' => 1, 'info' => 2, 'ok' => 3];
usort($ins, fn($a, $b) => $order[$a['severity']] <=> $order[$b['severity']]);

// ---------- response -----------------------------------

$r1 = fn($v) => $v === null ? null : round((float) $v, 1);

json_out([
    'status'       => 'success',
    'generated_at' => gmdate('Y-m-d\TH:i:s\Z'),
    'device'       => $device ?: $latest['device_id'],
    'window_hours' => $hours,
    'online'       => $online,
    'last_seen'    => iso_utc($latest['created_at']),
    'age_seconds'  => $age,
    'latest'       => [
        'temperature' => $t,
        'humidity'    => $rh,
        'rssi'        => $latest['rssi'] === null ? null : (int) $latest['rssi'],
    ],
    'stats' => [
        'samples'     => $n,
        'temperature' => ['avg' => $r1($w['t_avg']), 'min' => $r1($w['t_min']), 'max' => $r1($w['t_max'])],
        'humidity'    => ['avg' => $r1($w['h_avg']), 'min' => $r1($w['h_min']), 'max' => $r1($w['h_max'])],
        'completeness_pct' => $completeness,
    ],
    'derived' => [
        'dew_point'     => $r1($dew),
        'heat_index'    => $r1($feels),
        'comfort_score' => $score,
        'comfort_label' => comfort_label($score),
    ],
    'trend' => [
        'temperature_per_hour' => $r1($tSlope),
        'humidity_per_hour'    => $r1($hSlope),
        'temperature'          => direction($tSlope, 0.5),
        'humidity'             => direction($hSlope, 2.0),
    ],
    'insights' => $ins,
]);
