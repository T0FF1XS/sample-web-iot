-- =====================================================
-- IoT Climate Monitor - MySQL / MariaDB schema
-- Import with:  mysql -u root -p < database/schema.sql
-- All timestamps are stored in UTC.
-- =====================================================

CREATE DATABASE IF NOT EXISTS iot_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE iot_db;

-- One row per physical sensor node (auto-registered on first POST)
CREATE TABLE IF NOT EXISTS devices (
    device_id   VARCHAR(32)  NOT NULL,
    name        VARCHAR(64)  NULL,
    location    VARCHAR(64)  NULL,
    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen   TIMESTAMP    NULL,
    PRIMARY KEY (device_id)
) ENGINE=InnoDB;

-- One row per sensor reading
CREATE TABLE IF NOT EXISTS sensor_data (
    id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    device_id    VARCHAR(32)     NOT NULL,
    temperature  DECIMAL(5,2)    NOT NULL,
    humidity     DECIMAL(5,2)    NOT NULL,
    rssi         SMALLINT        NULL COMMENT 'WiFi signal strength in dBm',
    created_at   TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_device_time (device_id, created_at),
    KEY idx_time (created_at)
) ENGINE=InnoDB;

-- Optional: dedicated least-privilege account for the PHP API
-- CREATE USER 'iot_user'@'localhost' IDENTIFIED BY 'change-this-password';
-- GRANT SELECT, INSERT, UPDATE ON iot_db.* TO 'iot_user'@'localhost';
-- FLUSH PRIVILEGES;
