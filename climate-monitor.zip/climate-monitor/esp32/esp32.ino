// =====================================================
// IoT Climate Monitor - ESP32 + DHT11 firmware
//
// Reads temperature & humidity every SEND_INTERVAL ms and
// POSTs JSON to the PHP API:
//   { "device_id": "...", "temperature": 24.5, "humidity": 55.0, "rssi": -61 }
//
// Libraries (Arduino Library Manager):
//   - "DHT sensor library" by Adafruit  (+ Adafruit Unified Sensor)
// Board: any ESP32 dev module.   Wiring: DHT11 DATA -> GPIO 4, VCC -> 3V3, GND -> GND
// =====================================================

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <DHT.h>

// ---------- EDIT THESE ------------------------------------------------------
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// Full URL of api.php. Use the PC's LAN IP (not "localhost") or an https tunnel.
const char* SERVER_URL = "http://192.168.1.10/climate-monitor/api/api.php";

// Must match 'api_key' in api/config.php
const char* API_KEY    = "change-me-secret-key";

// Unique per board: letters, digits, - and _ only (max 32 chars)
const char* DEVICE_ID  = "esp32-01";
// ----------------------------------------------------------------------------

#define DHTPIN  4
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

const unsigned long SEND_INTERVAL = 5000;      // keep equal to 'expected_interval' x 1000
const int           WIFI_TIMEOUT_MS = 10000;
const int           MAX_SEND_RETRIES = 2;

unsigned long lastSend = 0;
int consecutiveFailures = 0;

// -----------------------------------------------------------------------------
bool connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return true;

  Serial.printf("Connecting to WiFi '%s'", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < WIFI_TIMEOUT_MS) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi OK, IP ");
    Serial.print(WiFi.localIP());
    Serial.printf(", RSSI %d dBm\n", WiFi.RSSI());
    return true;
  }
  Serial.println("WiFi FAILED - check SSID/password/router");
  return false;
}

// -----------------------------------------------------------------------------
// Returns true when the server answered 2xx
bool postReading(float temperature, float humidity) {
  String json = "{\"device_id\":\"" + String(DEVICE_ID) + "\","
                "\"temperature\":" + String(temperature, 2) + ","
                "\"humidity\":"    + String(humidity, 2)    + ","
                "\"rssi\":"        + String(WiFi.RSSI())    + "}";

  HTTPClient http;
  WiFiClientSecure secureClient;

  bool ok;
  if (String(SERVER_URL).startsWith("https://")) {
    secureClient.setInsecure();   // demo only: skips certificate check (ngrok etc.)
    ok = http.begin(secureClient, SERVER_URL);
  } else {
    ok = http.begin(SERVER_URL);
  }
  if (!ok) { Serial.println("http.begin failed"); return false; }

  http.setTimeout(8000);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-API-Key", API_KEY);
  http.addHeader("ngrok-skip-browser-warning", "1");   // harmless unless using ngrok

  int code = http.POST(json);
  Serial.print("POST " + json + " -> ");
  Serial.println(code);

  if (code > 0) Serial.println(http.getString());
  else          Serial.println(http.errorToString(code));

  http.end();
  return code >= 200 && code < 300;
}

// -----------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(500);
  dht.begin();
  Serial.println("\nIoT Climate Monitor starting...");
  connectWiFi();
}

void loop() {
  unsigned long now = millis();
  if (now - lastSend < SEND_INTERVAL) return;
  lastSend = now;

  if (!connectWiFi()) return;

  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (isnan(t) || isnan(h)) {
    Serial.println("DHT11 read failed - check wiring (DATA on GPIO 4, 10k pull-up)");
    return;
  }
  Serial.printf("Temperature %.1f C, Humidity %.1f %%\n", t, h);

  bool sent = false;
  for (int attempt = 0; attempt <= MAX_SEND_RETRIES && !sent; attempt++) {
    sent = postReading(t, h);
    if (!sent) delay(1000);
  }

  if (sent) {
    consecutiveFailures = 0;
  } else if (++consecutiveFailures >= 10) {
    Serial.println("10 failed uploads in a row - restarting");
    ESP.restart();
  }
}
