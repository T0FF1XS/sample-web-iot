#!/usr/bin/env python3
"""
Sensor simulator - lets the whole stack be demoed without an ESP32.

  Live mode  (posts to the real API, like the ESP32 does):
      python3 simulate.py live --url http://localhost:8000/api/api.php --key change-me-secret-key

  Seed mode  (prints SQL with historical data to import into MySQL):
      python3 simulate.py seed --hours 48 | mysql -u root iot_db
"""
import argparse
import json
import math
import random
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone


def reading(ts: datetime, device_seed: float = 0.0):
    """Realistic indoor climate: daily temperature cycle, humidity inversely related, noise."""
    h = ts.hour + ts.minute / 60
    temp = 25.5 + 4.0 * math.sin((h - 9) / 24 * 2 * math.pi) + device_seed + random.gauss(0, 0.15)
    hum = 62 - 1.6 * (temp - 25.5) * 2 + random.gauss(0, 0.8)
    # an occasional "cooking / shower" humidity bump
    if random.random() < 0.002:
        hum += random.uniform(8, 15)
    return round(temp, 2), round(max(5, min(99, hum)), 2)


def live(args):
    print(f"Posting every {args.interval}s to {args.url} as {args.device}  (Ctrl+C to stop)")
    while True:
        t, h = reading(datetime.now(timezone.utc), args.offset)
        body = json.dumps({"device_id": args.device, "temperature": t, "humidity": h,
                           "rssi": random.randint(-72, -48)}).encode()
        req = urllib.request.Request(args.url, data=body, method="POST", headers={
            "Content-Type": "application/json", "X-API-Key": args.key})
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                print(r.status, r.read().decode())
        except urllib.error.HTTPError as e:
            print("HTTP", e.code, e.read().decode())
        except Exception as e:  # network error
            print("ERROR", e)
        time.sleep(args.interval)


def seed(args):
    now = datetime.now(timezone.utc).replace(microsecond=0)
    start = now - timedelta(hours=args.hours)
    step = timedelta(seconds=args.step)
    out = sys.stdout
    out.write("USE iot_db;\nSET time_zone = '+00:00';\n")
    out.write(f"INSERT IGNORE INTO devices (device_id, name, location, last_seen) VALUES "
              f"('{args.device}', 'Demo node', 'Living room', UTC_TIMESTAMP());\n")
    ts, rows = start, []
    while ts <= now:
        # simulate occasional WiFi dropouts
        if random.random() > 0.01:
            t, h = reading(ts, args.offset)
            rows.append(f"('{args.device}',{t},{h},{random.randint(-75, -50)},'{ts:%Y-%m-%d %H:%M:%S}')")
        ts += step
    for i in range(0, len(rows), 1000):
        out.write("INSERT INTO sensor_data (device_id, temperature, humidity, rssi, created_at) VALUES\n")
        out.write(",\n".join(rows[i:i + 1000]) + ";\n")
    sys.stderr.write(f"Generated {len(rows)} rows\n")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="mode", required=True)

    a = sub.add_parser("live")
    a.add_argument("--url", default="http://localhost:8000/api/api.php")
    a.add_argument("--key", default="change-me-secret-key")
    a.add_argument("--device", default="sim-01")
    a.add_argument("--interval", type=float, default=5)
    a.add_argument("--offset", type=float, default=0.0, help="temperature offset for this node")
    a.set_defaults(fn=live)

    b = sub.add_parser("seed")
    b.add_argument("--hours", type=float, default=24)
    b.add_argument("--step", type=int, default=5, help="seconds between seeded readings")
    b.add_argument("--device", default="sim-01")
    b.add_argument("--offset", type=float, default=0.0)
    b.set_defaults(fn=seed)

    args = p.parse_args()
    try:
        args.fn(args)
    except KeyboardInterrupt:
        pass
