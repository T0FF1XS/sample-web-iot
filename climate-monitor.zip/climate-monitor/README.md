# IoT Climate Monitor

An ESP32 + DHT11 node sends temperature and humidity to a **PHP API**, which stores readings in **MySQL**. A **web dashboard** shows live and historical data and turns it into **actionable insights** (comfort score, dew point, mold/condensation risk, trends, offline detection).

```
ESP32 + DHT11 --HTTP POST JSON (X-API-Key)--> api/api.php --> MySQL (iot_db)
                                                   ^                |
Browser dashboard <-- api.php (history) + insights.php (analysis) --+
```

## Project layout

| Path | Purpose |
|---|---|
| `esp32/esp32.ino` | Firmware: reads DHT11, uploads every 5 s, WiFi reconnect, retries, auto-restart |
| `api/api.php` | `POST` store reading (API-key protected) / `GET` history & device list |
| `api/insights.php` | Analysis engine: stats, derived metrics, trend, recommendations |
| `api/lib.php`, `api/config.php` | DB connection, validation helpers, thresholds and secrets |
| `database/schema.sql` | `devices` and `sensor_data` tables |
| `dashboard/index.html` | Responsive dashboard (Chart.js, light/dark theme, CSV export) |
| `simulator/simulate.py` | Fake sensor: seeds history or posts live, so you can demo without hardware |

## Setup

1. **Database** – `mysql -u root -p < database/schema.sql`
2. **Server** – copy the folder into XAMPP/WAMP `htdocs/` (or run `php -S 0.0.0.0:8000` from this folder). Edit `api/config.php` (DB user/password, and **change `api_key`**). Env vars `IOT_DB_*` and `IOT_API_KEY` override the file.
3. **Dashboard** – open `http://localhost:8000/dashboard/` (or `/climate-monitor/dashboard/` under XAMPP).
4. **Demo data (no hardware)**
   ```bash
   python3 simulator/simulate.py seed --hours 24 | mysql -u root iot_db
   python3 simulator/simulate.py live --url http://localhost:8000/api/api.php --key <your key>
   ```
5. **ESP32** – open `esp32/esp32.ino`, set `WIFI_SSID`, `WIFI_PASSWORD`, `SERVER_URL` (use the PC's LAN IP, not `localhost`), `API_KEY`, `DEVICE_ID`. Wiring: DHT11 DATA→GPIO 4, VCC→3V3, GND→GND. Install the *DHT sensor library* (Adafruit).

## API

`POST api/api.php` – header `X-API-Key: <key>`
```json
{ "device_id": "esp32-01", "temperature": 24.5, "humidity": 55.0, "rssi": -61 }
```
→ `201 {"status":"success","id":123,...}`; errors: `400` invalid data, `401` bad key, `500` DB error.

`GET api/api.php?hours=1&device=esp32-01` – history (oldest first). Windows over 1 h are averaged into ~360 buckets with min/max per bucket.
`GET api/api.php?devices=1` – known devices and `last_seen`.
`GET api/insights.php?hours=24&device=esp32-01` – analysis (see below).

## Insights the dashboard provides

| Insight | How it is computed | Action suggested |
|---|---|---|
| Comfort score (0-100) | Penalty for distance from 20.5-24.5 °C and 40-60 % RH | Overall status |
| Too hot / cold | Thresholds in `config.php` | Ventilate, cool, heat |
| Mold & condensation risk | RH ≥ 65 / 75 %, dew point within 2.5 °C of air temp | Dehumidify, ventilate |
| Heat index | NOAA Rothfusz regression | Prioritise dehumidifying |
| Fast temperature change | Least-squares slope over last 30 min | Look for heat source / open window |
| Recurring problems | % of selected range above limits (≥ 25 %) | Permanent fix |
| Unusual reading | z-score ≥ 3 vs window average | Check sensor placement |
| Sensor offline / data gaps / weak WiFi | Age of last reading, completeness %, RSSI | Check power / WiFi |

## Security notes

- Writes need the shared `X-API-Key`; all SQL uses prepared statements; the dashboard renders API text with `textContent` (no HTML injection).
- Use HTTPS (or a tunnel such as ngrok) if the server is reachable from the internet, and a dedicated MySQL user (see the commented block in `schema.sql`).
- Reference sample credentials (WiFi password, ngrok URL) were intentionally **not** reused.

## Suggested team roles (3-4 members)

| Role | Owns | Deliverables |
|---|---|---|
| **1. Hardware / firmware** | `esp32/` | Wiring diagram, firmware, reliability test (WiFi drop, sensor unplugged) |
| **2. Backend / API** | `api/` | Endpoints, validation, API docs, test with curl/Postman |
| **3. Database & insights** | `database/`, `api/insights.php` | Schema, indexes, thresholds, insight rules and their justification |
| **4. Frontend / UX & documentation** | `dashboard/`, README, demo | Dashboard, screenshots, presentation / demo video |

*(Replace with your names; with 3 people, merge roles 3 and 4's documentation into the others.)*

## Ideas for extension

Email/Telegram alert when an insight turns critical, additional sensors (gas, light), data retention job (`DELETE ... WHERE created_at < NOW() - INTERVAL 90 DAY`), login for the dashboard.
